(function (Scratch) {
  "use strict";

  if (!Scratch.extensions.unsandboxed) {
    throw new Error("Mega Studio Extension V2 MAX требует unsandboxed режим.");
  }

  const Cast = Scratch.Cast;
  const BlockType = Scratch.BlockType;
  const ArgumentType = Scratch.ArgumentType;

  class MegaStudioExtensionV2MAX {
    constructor() {
      this.vm = Scratch.vm;
      this.runtime = Scratch.vm.runtime;

      this.fsKey = "MegaStudioExtensionV2MAX_FS";
      this.virtualFS = this._loadFS();
      this.cwd = "/";

      this.elements = {};
      this.buttonClicks = {};
      this.tabGroups = {};
      this.overlayElements = {};
      this.attachedElements = {};
      this.canvases = {};
      this.vectors = {};
      this.particles = [];
      this.vars = {};
      this.lastHttpText = "";
      this.lastHttpStatus = 0;

      this._ensureRoot();
      this._startOverlayLoop();
    }

    getInfo() {
      return {
        id: "megastudiov2max",
        name: "🟣 Mega Studio V2 MAX",
        color1: "#7D5FFF",
        color2: "#5F6FFF",
        color3: "#4C56D7",
        blocks: [
          { blockType: BlockType.LABEL, text: "🪟 Окна" },

          {
            opcode: "createWindow",
            blockType: BlockType.COMMAND,
            text: "создать окно [ID] x [X] y [Y] w [W] h [H] заголовок [TITLE]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "win1" },
              X: { type: ArgumentType.NUMBER, defaultValue: 50 },
              Y: { type: ArgumentType.NUMBER, defaultValue: 50 },
              W: { type: ArgumentType.NUMBER, defaultValue: 360 },
              H: { type: ArgumentType.NUMBER, defaultValue: 260 },
              TITLE: { type: ArgumentType.STRING, defaultValue: "Mega Window" }
            }
          },
          {
            opcode: "showWindow",
            blockType: BlockType.COMMAND,
            text: "показать окно [ID]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "win1" }
            }
          },
          {
            opcode: "hideWindow",
            blockType: BlockType.COMMAND,
            text: "скрыть окно [ID]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "win1" }
            }
          },
          {
            opcode: "moveWindow",
            blockType: BlockType.COMMAND,
            text: "переместить окно [ID] x [X] y [Y]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "win1" },
              X: { type: ArgumentType.NUMBER, defaultValue: 100 },
              Y: { type: ArgumentType.NUMBER, defaultValue: 100 }
            }
          },
          {
            opcode: "resizeWindow",
            blockType: BlockType.COMMAND,
            text: "изменить окно [ID] w [W] h [H]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "win1" },
              W: { type: ArgumentType.NUMBER, defaultValue: 420 },
              H: { type: ArgumentType.NUMBER, defaultValue: 320 }
            }
          },
          {
            opcode: "setWindowTitle",
            blockType: BlockType.COMMAND,
            text: "окну [ID] заголовок [TITLE]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "win1" },
              TITLE: { type: ArgumentType.STRING, defaultValue: "Новое окно" }
            }
          },
          {
            opcode: "centerWindow",
            blockType: BlockType.COMMAND,
            text: "центрировать окно [ID]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "win1" }
            }
          },
          {
            opcode: "removeElement",
            blockType: BlockType.COMMAND,
            text: "удалить элемент [ID]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "win1" }
            }
          },

          { blockType: BlockType.LABEL, text: "🧩 UI элементы" },

          {
            opcode: "createLabel",
            blockType: BlockType.COMMAND,
            text: "создать label [ID] в [PARENT] текст [TEXT]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "label1" },
              PARENT: { type: ArgumentType.STRING, defaultValue: "win1" },
              TEXT: { type: ArgumentType.STRING, defaultValue: "Привет" }
            }
          },
          {
            opcode: "createButton",
            blockType: BlockType.COMMAND,
            text: "создать кнопку [ID] в [PARENT] текст [TEXT]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "btn1" },
              PARENT: { type: ArgumentType.STRING, defaultValue: "win1" },
              TEXT: { type: ArgumentType.STRING, defaultValue: "Нажми" }
            }
          },
          {
            opcode: "buttonWasClicked",
            blockType: BlockType.BOOLEAN,
            text: "кнопка [ID] была нажата?",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "btn1" }
            }
          },
          {
            opcode: "resetButtonClick",
            blockType: BlockType.COMMAND,
            text: "сбросить клик кнопки [ID]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "btn1" }
            }
          },
          {
            opcode: "createInput",
            blockType: BlockType.COMMAND,
            text: "создать input [ID] в [PARENT] placeholder [PLACEHOLDER]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "input1" },
              PARENT: { type: ArgumentType.STRING, defaultValue: "win1" },
              PLACEHOLDER: { type: ArgumentType.STRING, defaultValue: "Введите текст..." }
            }
          },
          {
            opcode: "getInputText",
            blockType: BlockType.REPORTER,
            text: "текст input [ID]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "input1" }
            }
          },
          {
            opcode: "setInputText",
            blockType: BlockType.COMMAND,
            text: "установить input [ID] текст [TEXT]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "input1" },
              TEXT: { type: ArgumentType.STRING, defaultValue: "Привет" }
            }
          },
          {
            opcode: "createTextarea",
            blockType: BlockType.COMMAND,
            text: "создать textarea [ID] в [PARENT] текст [TEXT]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "ta1" },
              PARENT: { type: ArgumentType.STRING, defaultValue: "win1" },
              TEXT: { type: ArgumentType.STRING, defaultValue: "Многострочный текст" }
            }
          },
          {
            opcode: "createCheckbox",
            blockType: BlockType.COMMAND,
            text: "создать checkbox [ID] в [PARENT] текст [TEXT]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "check1" },
              PARENT: { type: ArgumentType.STRING, defaultValue: "win1" },
              TEXT: { type: ArgumentType.STRING, defaultValue: "Согласен" }
            }
          },
          {
            opcode: "checkboxChecked",
            blockType: BlockType.BOOLEAN,
            text: "checkbox [ID] включён?",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "check1" }
            }
          },
          {
            opcode: "createProgressBar",
            blockType: BlockType.COMMAND,
            text: "создать progress [ID] в [PARENT] значение [VALUE] максимум [MAX]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "progress1" },
              PARENT: { type: ArgumentType.STRING, defaultValue: "win1" },
              VALUE: { type: ArgumentType.NUMBER, defaultValue: 25 },
              MAX: { type: ArgumentType.NUMBER, defaultValue: 100 }
            }
          },
          {
            opcode: "setProgressValue",
            blockType: BlockType.COMMAND,
            text: "progress [ID] значение [VALUE]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "progress1" },
              VALUE: { type: ArgumentType.NUMBER, defaultValue: 80 }
            }
          },
          {
            opcode: "getProgressValue",
            blockType: BlockType.REPORTER,
            text: "значение progress [ID]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "progress1" }
            }
          },
          {
            opcode: "createList",
            blockType: BlockType.COMMAND,
            text: "создать список [ID] в [PARENT] из [ITEMS]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "list1" },
              PARENT: { type: ArgumentType.STRING, defaultValue: "win1" },
              ITEMS: { type: ArgumentType.STRING, defaultValue: "яблоко,банан,апельсин" }
            }
          },
          {
            opcode: "getListValue",
            blockType: BlockType.REPORTER,
            text: "выбранный элемент списка [ID]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "list1" }
            }
          },
          {
            opcode: "createTabs",
            blockType: BlockType.COMMAND,
            text: "создать вкладки [ID] в [PARENT] из [TABS]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "tabs1" },
              PARENT: { type: ArgumentType.STRING, defaultValue: "win1" },
              TABS: { type: ArgumentType.STRING, defaultValue: "Главная,Настройки,О программе" }
            }
          },
          {
            opcode: "getActiveTab",
            blockType: BlockType.REPORTER,
            text: "активная вкладка [ID]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "tabs1" }
            }
          },
          {
            opcode: "createSlider",
            blockType: BlockType.COMMAND,
            text: "создать slider [ID] в [PARENT] мин [MIN] макс [MAX] значение [VALUE]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "slider1" },
              PARENT: { type: ArgumentType.STRING, defaultValue: "win1" },
              MIN: { type: ArgumentType.NUMBER, defaultValue: 0 },
              MAX: { type: ArgumentType.NUMBER, defaultValue: 100 },
              VALUE: { type: ArgumentType.NUMBER, defaultValue: 50 }
            }
          },
          {
            opcode: "getSliderValue",
            blockType: BlockType.REPORTER,
            text: "значение slider [ID]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "slider1" }
            }
          },
          {
            opcode: "createColorPicker",
            blockType: BlockType.COMMAND,
            text: "создать color picker [ID] в [PARENT] цвет [COLOR]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "color1" },
              PARENT: { type: ArgumentType.STRING, defaultValue: "win1" },
              COLOR: { type: ArgumentType.STRING, defaultValue: "#7D5FFF" }
            }
          },
          {
            opcode: "getColorPickerValue",
            blockType: BlockType.REPORTER,
            text: "цвет color picker [ID]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "color1" }
            }
          },
          {
            opcode: "createImageElement",
            blockType: BlockType.COMMAND,
            text: "создать изображение [ID] в [PARENT] URL [URL] w [W] h [H]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "img1" },
              PARENT: { type: ArgumentType.STRING, defaultValue: "win1" },
              URL: { type: ArgumentType.STRING, defaultValue: "https://extensions.turbowarp.org/dango.svg" },
              W: { type: ArgumentType.NUMBER, defaultValue: 100 },
              H: { type: ArgumentType.NUMBER, defaultValue: 100 }
            }
          },
          {
            opcode: "createIFrame",
            blockType: BlockType.COMMAND,
            text: "создать iframe [ID] в [PARENT] URL [URL] w [W] h [H]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "frame1" },
              PARENT: { type: ArgumentType.STRING, defaultValue: "win1" },
              URL: { type: ArgumentType.STRING, defaultValue: "https://example.com" },
              W: { type: ArgumentType.NUMBER, defaultValue: 250 },
              H: { type: ArgumentType.NUMBER, defaultValue: 140 }
            }
          },

          { blockType: BlockType.LABEL, text: "🎨 HTML / CSS / JS" },

          {
            opcode: "setElementHTML",
            blockType: BlockType.COMMAND,
            text: "элементу [ID] HTML [HTML]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "win1" },
              HTML: { type: ArgumentType.STRING, defaultValue: "<b>Hello</b>" }
            }
          },
          {
            opcode: "setElementText",
            blockType: BlockType.COMMAND,
            text: "элементу [ID] текст [TEXT]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "label1" },
              TEXT: { type: ArgumentType.STRING, defaultValue: "Привет" }
            }
          },
          {
            opcode: "setElementStyle",
            blockType: BlockType.COMMAND,
            text: "элементу [ID] CSS [CSS]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "win1" },
              CSS: { type: ArgumentType.STRING, defaultValue: "background:#fff;" }
            }
          },
          {
            opcode: "runJavaScript",
            blockType: BlockType.REPORTER,
            text: "выполнить JavaScript [CODE]",
            arguments: {
              CODE: { type: ArgumentType.STRING, defaultValue: "1+1" }
            }
          },

          { blockType: BlockType.LABEL, text: "🐍 Mini-code" },

          {
            opcode: "runMiniCode",
            blockType: BlockType.REPORTER,
            text: "выполнить mini-code [CODE]",
            arguments: {
              CODE: { type: ArgumentType.STRING, defaultValue: "print Hello" }
            }
          },

          { blockType: BlockType.LABEL, text: "🌐 Запросы" },

          {
            opcode: "httpGet",
            blockType: BlockType.REPORTER,
            text: "GET [URL]",
            arguments: {
              URL: { type: ArgumentType.STRING, defaultValue: "https://httpbin.org/get" }
            }
          },
          {
            opcode: "httpPost",
            blockType: BlockType.REPORTER,
            text: "POST [URL] тело [BODY]",
            arguments: {
              URL: { type: ArgumentType.STRING, defaultValue: "https://httpbin.org/post" },
              BODY: { type: ArgumentType.STRING, defaultValue: "{\"hello\":true}" }
            }
          },
          {
            opcode: "httpLastStatus",
            blockType: BlockType.REPORTER,
            text: "последний HTTP статус"
          },

          { blockType: BlockType.LABEL, text: "📁 Файлы" },

          {
            opcode: "fsCreateFile",
            blockType: BlockType.COMMAND,
            text: "создать файл [PATH] с [CONTENT]",
            arguments: {
              PATH: { type: ArgumentType.STRING, defaultValue: "/file.txt" },
              CONTENT: { type: ArgumentType.STRING, defaultValue: "hello" }
            }
          },
          {
            opcode: "fsReadFile",
            blockType: BlockType.REPORTER,
            text: "прочитать файл [PATH]",
            arguments: {
              PATH: { type: ArgumentType.STRING, defaultValue: "/file.txt" }
            }
          },
          {
            opcode: "fsWriteFile",
            blockType: BlockType.COMMAND,
            text: "записать файл [PATH] = [CONTENT]",
            arguments: {
              PATH: { type: ArgumentType.STRING, defaultValue: "/file.txt" },
              CONTENT: { type: ArgumentType.STRING, defaultValue: "new text" }
            }
          },
          {
            opcode: "fsMkdir",
            blockType: BlockType.COMMAND,
            text: "создать папку [PATH]",
            arguments: {
              PATH: { type: ArgumentType.STRING, defaultValue: "/folder" }
            }
          },
          {
            opcode: "fsList",
            blockType: BlockType.REPORTER,
            text: "список в [PATH]",
            arguments: {
              PATH: { type: ArgumentType.STRING, defaultValue: "/" }
            }
          },

          { blockType: BlockType.LABEL, text: "🎨 Canvas" },

          {
            opcode: "canvasCreate",
            blockType: BlockType.COMMAND,
            text: "создать canvas [ID] [W]x[H]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "canvas1" },
              W: { type: ArgumentType.NUMBER, defaultValue: 300 },
              H: { type: ArgumentType.NUMBER, defaultValue: 200 }
            }
          },
          {
            opcode: "canvasRect",
            blockType: BlockType.COMMAND,
            text: "canvas [ID] прямоугольник x [X] y [Y] w [W] h [H] цвет [COLOR]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "canvas1" },
              X: { type: ArgumentType.NUMBER, defaultValue: 10 },
              Y: { type: ArgumentType.NUMBER, defaultValue: 10 },
              W: { type: ArgumentType.NUMBER, defaultValue: 100 },
              H: { type: ArgumentType.NUMBER, defaultValue: 60 },
              COLOR: { type: ArgumentType.STRING, defaultValue: "#ff0000" }
            }
          },
          {
            opcode: "canvasCircle",
            blockType: BlockType.COMMAND,
            text: "canvas [ID] круг x [X] y [Y] r [R] цвет [COLOR]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "canvas1" },
              X: { type: ArgumentType.NUMBER, defaultValue: 120 },
              Y: { type: ArgumentType.NUMBER, defaultValue: 80 },
              R: { type: ArgumentType.NUMBER, defaultValue: 30 },
              COLOR: { type: ArgumentType.STRING, defaultValue: "#00ff00" }
            }
          },
          {
            opcode: "canvasText",
            blockType: BlockType.COMMAND,
            text: "canvas [ID] текст [TEXT] x [X] y [Y] размер [SIZE] цвет [COLOR]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "canvas1" },
              TEXT: { type: ArgumentType.STRING, defaultValue: "Hello" },
              X: { type: ArgumentType.NUMBER, defaultValue: 20 },
              Y: { type: ArgumentType.NUMBER, defaultValue: 40 },
              SIZE: { type: ArgumentType.NUMBER, defaultValue: 20 },
              COLOR: { type: ArgumentType.STRING, defaultValue: "#000000" }
            }
          },
          {
            opcode: "canvasDataURL",
            blockType: BlockType.REPORTER,
            text: "canvas [ID] как data URL",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "canvas1" }
            }
          },

          { blockType: BlockType.LABEL, text: "🔢 Векторы и частицы" },

          {
            opcode: "vectorCreate",
            blockType: BlockType.COMMAND,
            text: "создать вектор [NAME] x [X] y [Y] z [Z]",
            arguments: {
              NAME: { type: ArgumentType.STRING, defaultValue: "v1" },
              X: { type: ArgumentType.NUMBER, defaultValue: 1 },
              Y: { type: ArgumentType.NUMBER, defaultValue: 2 },
              Z: { type: ArgumentType.NUMBER, defaultValue: 3 }
            }
          },
          {
            opcode: "vectorAdd",
            blockType: BlockType.REPORTER,
            text: "вектор [A] + [B]",
            arguments: {
              A: { type: ArgumentType.STRING, defaultValue: "v1" },
              B: { type: ArgumentType.STRING, defaultValue: "v2" }
            }
          },
          {
            opcode: "particleCreate",
            blockType: BlockType.COMMAND,
            text: "создать частицу x [X] y [Y] vx [VX] vy [VY] жизнь [LIFE]",
            arguments: {
              X: { type: ArgumentType.NUMBER, defaultValue: 0 },
              Y: { type: ArgumentType.NUMBER, defaultValue: 0 },
              VX: { type: ArgumentType.NUMBER, defaultValue: 1 },
              VY: { type: ArgumentType.NUMBER, defaultValue: -1 },
              LIFE: { type: ArgumentType.NUMBER, defaultValue: 100 }
            }
          },
          {
            opcode: "particleStep",
            blockType: BlockType.COMMAND,
            text: "обновить частицы гравитация [G]",
            arguments: {
              G: { type: ArgumentType.NUMBER, defaultValue: 0.1 }
            }
          },
          {
            opcode: "particleCount",
            blockType: BlockType.REPORTER,
            text: "количество частиц"
          },

          { blockType: BlockType.LABEL, text: "🎮 Спрайты" },

          {
            opcode: "spriteExists",
            blockType: BlockType.BOOLEAN,
            text: "спрайт [NAME] существует?",
            arguments: {
              NAME: { type: ArgumentType.STRING, defaultValue: "Sprite1" }
            }
          },
          {
            opcode: "spriteSetXY",
            blockType: BlockType.COMMAND,
            text: "спрайт [NAME] поставить x [X] y [Y]",
            arguments: {
              NAME: { type: ArgumentType.STRING, defaultValue: "Sprite1" },
              X: { type: ArgumentType.NUMBER, defaultValue: 0 },
              Y: { type: ArgumentType.NUMBER, defaultValue: 0 }
            }
          },
          {
            opcode: "spriteSetCostumeByName",
            blockType: BlockType.COMMAND,
            text: "спрайту [NAME] установить костюм [COSTUME]",
            arguments: {
              NAME: { type: ArgumentType.STRING, defaultValue: "Sprite1" },
              COSTUME: { type: ArgumentType.STRING, defaultValue: "costume1" }
            }
          },
          {
            opcode: "attachLabelToSprite",
            blockType: BlockType.COMMAND,
            text: "прикрепить текст [ID] к спрайту [SPRITE] текст [TEXT] dx [DX] dy [DY]",
            arguments: {
              ID: { type: ArgumentType.STRING, defaultValue: "overlay1" },
              SPRITE: { type: ArgumentType.STRING, defaultValue: "Sprite1" },
              TEXT: { type: ArgumentType.STRING, defaultValue: "HP:100" },
              DX: { type: ArgumentType.NUMBER, defaultValue: 0 },
              DY: { type: ArgumentType.NUMBER, defaultValue: -40 }
            }
          },

          { blockType: BlockType.LABEL, text: "📚 Документация" },

          {
            opcode: "docsSections",
            blockType: BlockType.REPORTER,
            text: "разделы документации"
          },
          {
            opcode: "docsGet",
            blockType: BlockType.REPORTER,
            text: "документация [SECTION]",
            arguments: {
              SECTION: { type: ArgumentType.STRING, defaultValue: "окна" }
            }
          }
        ]
      };
    }

    _loadFS() {
      try {
        const raw = localStorage.getItem(this.fsKey);
        if (raw) return JSON.parse(raw);
      } catch (e) {}
      return { "/": { type: "dir", children: {} } };
    }

    _saveFS() {
      try {
        localStorage.setItem(this.fsKey, JSON.stringify(this.virtualFS));
      } catch (e) {}
    }

    _normPath(path) {
      path = Cast.toString(path).trim();
      if (!path) path = "/";
      if (!path.startsWith("/")) {
        path = this.cwd === "/" ? "/" + path : this.cwd + "/" + path;
      }
      path = path.replace(/\/+/g, "/");
      const parts = path.split("/");
      const out = [];
      for (const part of parts) {
        if (!part || part === ".") continue;
        if (part === "..") out.pop();
        else out.push(part);
      }
      return "/" + out.join("/");
    }

    _getNode(path) {
      const p = this._normPath(path);
      if (p === "/") return this.virtualFS["/"];
      const parts = p.split("/").filter(Boolean);
      let node = this.virtualFS["/"];
      for (const part of parts) {
        if (!node.children || !node.children[part]) return null;
        node = node.children[part];
      }
      return node;
    }

    _getParentAndName(path) {
      const p = this._normPath(path);
      if (p === "/") return null;
      const parts = p.split("/").filter(Boolean);
      const name = parts.pop();
      const parentPath = "/" + parts.join("/");
      const parent = this._getNode(parentPath || "/");
      return { parent, name };
    }

    _deepCopy(obj) {
      return JSON.parse(JSON.stringify(obj));
    }

    _ensureRoot() {
      if (!document.getElementById("mega-studio-v2-root")) {
        const root = document.createElement("div");
        root.id = "mega-studio-v2-root";
        root.style.position = "fixed";
        root.style.left = "0";
        root.style.top = "0";
        root.style.width = "100vw";
        root.style.height = "100vh";
        root.style.pointerEvents = "none";
        root.style.zIndex = "999999";
        document.body.appendChild(root);
      }
    }

    _getRoot() {
      this._ensureRoot();
      return document.getElementById("mega-studio-v2-root");
    }

    _getParentContainer(id) {
      const parent = this.elements[Cast.toString(id)];
      if (!parent) return null;
      if (parent._body) return parent._body;
      return parent;
    }

    _windowStyle(el) {
      el.style.background = "linear-gradient(135deg, rgba(125,95,255,0.96), rgba(95,111,255,0.96))";
      el.style.border = "1px solid rgba(255,255,255,0.25)";
      el.style.borderRadius = "14px";
      el.style.overflow = "hidden";
      el.style.pointerEvents = "auto";
      el.style.boxShadow = "0 10px 30px rgba(60,40,140,0.35)";
      el.style.backdropFilter = "blur(8px)";
      el.style.fontFamily = "Arial, sans-serif";
      el.style.color = "#fff";
    }

    createWindow({ ID, X, Y, W, H, TITLE }) {
      const id = Cast.toString(ID);
      const root = this._getRoot();

      if (this.elements[id]) this.elements[id].remove();

      const win = document.createElement("div");
      win.style.position = "fixed";
      win.style.left = Cast.toNumber(X) + "px";
      win.style.top = Cast.toNumber(Y) + "px";
      win.style.width = Cast.toNumber(W) + "px";
      win.style.height = Cast.toNumber(H) + "px";
      this._windowStyle(win);

      const header = document.createElement("div");
      header.textContent = Cast.toString(TITLE);
      header.style.background = "linear-gradient(90deg, rgba(70,50,180,0.9), rgba(80,110,255,0.9))";
      header.style.padding = "10px 12px";
      header.style.cursor = "move";
      header.style.userSelect = "none";
      header.style.fontSize = "14px";
      header.style.fontWeight = "bold";

      const body = document.createElement("div");
      body.style.padding = "10px";
      body.style.height = "calc(100% - 40px)";
      body.style.overflow = "auto";
      body.style.display = "flex";
      body.style.flexDirection = "column";
      body.style.gap = "8px";
      body.style.boxSizing = "border-box";
      body.style.background = "rgba(255,255,255,0.10)";

      win.appendChild(header);
      win.appendChild(body);
      root.appendChild(win);

      this._makeDraggable(win, header);

      win._body = body;
      win._header = header;
      this.elements[id] = win;
    }

    _makeDraggable(win, handle) {
      let dragging = false;
      let offsetX = 0;
      let offsetY = 0;

      handle.addEventListener("mousedown", e => {
        dragging = true;
        offsetX = e.clientX - win.offsetLeft;
        offsetY = e.clientY - win.offsetTop;
        e.preventDefault();
      });

      document.addEventListener("mousemove", e => {
        if (!dragging) return;
        win.style.left = e.clientX - offsetX + "px";
        win.style.top = e.clientY - offsetY + "px";
      });

      document.addEventListener("mouseup", () => {
        dragging = false;
      });
    }

    showWindow({ ID }) {
      const el = this.elements[Cast.toString(ID)];
      if (el) el.style.display = "";
    }

    hideWindow({ ID }) {
      const el = this.elements[Cast.toString(ID)];
      if (el) el.style.display = "none";
    }

    moveWindow({ ID, X, Y }) {
      const el = this.elements[Cast.toString(ID)];
      if (!el) return;
      el.style.left = Cast.toNumber(X) + "px";
      el.style.top = Cast.toNumber(Y) + "px";
    }

    resizeWindow({ ID, W, H }) {
      const el = this.elements[Cast.toString(ID)];
      if (!el) return;
      el.style.width = Cast.toNumber(W) + "px";
      el.style.height = Cast.toNumber(H) + "px";
    }

    setWindowTitle({ ID, TITLE }) {
      const el = this.elements[Cast.toString(ID)];
      if (el && el._header) el._header.textContent = Cast.toString(TITLE);
    }

    centerWindow({ ID }) {
      const el = this.elements[Cast.toString(ID)];
      if (!el) return;
      const w = el.offsetWidth || 300;
      const h = el.offsetHeight || 200;
      el.style.left = ((window.innerWidth - w) / 2) + "px";
      el.style.top = ((window.innerHeight - h) / 2) + "px";
    }

    createLabel({ ID, PARENT, TEXT }) {
      const id = Cast.toString(ID);
      const parent = this._getParentContainer(PARENT);
      if (!parent) return;
      if (this.elements[id]) this.elements[id].remove();

      const div = document.createElement("div");
      div.textContent = Cast.toString(TEXT);
      div.style.padding = "4px 0";
      div.style.pointerEvents = "auto";

      parent.appendChild(div);
      this.elements[id] = div;
    }

    createButton({ ID, PARENT, TEXT }) {
      const id = Cast.toString(ID);
      const parent = this._getParentContainer(PARENT);
      if (!parent) return;
      if (this.elements[id]) this.elements[id].remove();

      const btn = document.createElement("button");
      btn.textContent = Cast.toString(TEXT);
      btn.style.padding = "10px 14px";
      btn.style.borderRadius = "10px";
      btn.style.border = "1px solid rgba(255,255,255,0.2)";
      btn.style.background = "linear-gradient(90deg,#8b5cf6,#4f46e5)";
      btn.style.color = "#fff";
      btn.style.cursor = "pointer";
      btn.style.pointerEvents = "auto";
      btn.style.fontWeight = "bold";

      this.buttonClicks[id] = false;
      btn.addEventListener("click", () => {
        this.buttonClicks[id] = true;
      });

      parent.appendChild(btn);
      this.elements[id] = btn;
    }

    buttonWasClicked({ ID }) {
      return !!this.buttonClicks[Cast.toString(ID)];
    }

    resetButtonClick({ ID }) {
      this.buttonClicks[Cast.toString(ID)] = false;
    }

    createInput({ ID, PARENT, PLACEHOLDER }) {
      const id = Cast.toString(ID);
      const parent = this._getParentContainer(PARENT);
      if (!parent) return;
      if (this.elements[id]) this.elements[id].remove();

      const input = document.createElement("input");
      input.type = "text";
      input.placeholder = Cast.toString(PLACEHOLDER);
      input.style.padding = "10px";
      input.style.borderRadius = "10px";
      input.style.border = "1px solid rgba(255,255,255,0.3)";
      input.style.background = "rgba(255,255,255,0.92)";
      input.style.pointerEvents = "auto";

      parent.appendChild(input);
      this.elements[id] = input;
    }

    getInputText({ ID }) {
      const el = this.elements[Cast.toString(ID)];
      return el ? el.value : "";
    }

    setInputText({ ID, TEXT }) {
      const el = this.elements[Cast.toString(ID)];
      if (el) el.value = Cast.toString(TEXT);
    }

    createTextarea({ ID, PARENT, TEXT }) {
      const id = Cast.toString(ID);
      const parent = this._getParentContainer(PARENT);
      if (!parent) return;
      if (this.elements[id]) this.elements[id].remove();

      const ta = document.createElement("textarea");
      ta.value = Cast.toString(TEXT);
      ta.style.minHeight = "80px";
      ta.style.padding = "10px";
      ta.style.borderRadius = "10px";
      ta.style.border = "1px solid rgba(255,255,255,0.3)";
      ta.style.background = "rgba(255,255,255,0.92)";
      ta.style.pointerEvents = "auto";

      parent.appendChild(ta);
      this.elements[id] = ta;
    }

    createCheckbox({ ID, PARENT, TEXT }) {
      const id = Cast.toString(ID);
      const parent = this._getParentContainer(PARENT);
      if (!parent) return;
      if (this.elements[id]) this.elements[id].remove();

      const label = document.createElement("label");
      label.style.display = "flex";
      label.style.alignItems = "center";
      label.style.gap = "8px";
      label.style.pointerEvents = "auto";

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";

      const span = document.createElement("span");
      span.textContent = Cast.toString(TEXT);

      label.appendChild(checkbox);
      label.appendChild(span);
      label._checkbox = checkbox;

      parent.appendChild(label);
      this.elements[id] = label;
    }

    checkboxChecked({ ID }) {
      const el = this.elements[Cast.toString(ID)];
      return !!(el && el._checkbox && el._checkbox.checked);
    }

    createProgressBar({ ID, PARENT, VALUE, MAX }) {
      const id = Cast.toString(ID);
      const parent = this._getParentContainer(PARENT);
      if (!parent) return;
      if (this.elements[id]) this.elements[id].remove();

      const progress = document.createElement("progress");
      progress.max = Cast.toNumber(MAX);
      progress.value = Cast.toNumber(VALUE);
      progress.style.width = "100%";
      progress.style.pointerEvents = "auto";

      parent.appendChild(progress);
      this.elements[id] = progress;
    }

    setProgressValue({ ID, VALUE }) {
      const el = this.elements[Cast.toString(ID)];
      if (el) el.value = Cast.toNumber(VALUE);
    }

    getProgressValue({ ID }) {
      const el = this.elements[Cast.toString(ID)];
      return el ? el.value : 0;
    }

    createList({ ID, PARENT, ITEMS }) {
      const id = Cast.toString(ID);
      const parent = this._getParentContainer(PARENT);
      if (!parent) return;
      if (this.elements[id]) this.elements[id].remove();

      const select = document.createElement("select");
      select.style.padding = "10px";
      select.style.borderRadius = "10px";
      select.style.pointerEvents = "auto";

      const items = Cast.toString(ITEMS).split(",");
      for (const item of items) {
        const option = document.createElement("option");
        option.value = item.trim();
        option.textContent = item.trim();
        select.appendChild(option);
      }

      parent.appendChild(select);
      this.elements[id] = select;
    }

    getListValue({ ID }) {
      const el = this.elements[Cast.toString(ID)];
      return el ? el.value : "";
    }

    createTabs({ ID, PARENT, TABS }) {
      const id = Cast.toString(ID);
      const parent = this._getParentContainer(PARENT);
      if (!parent) return;
      if (this.elements[id]) this.elements[id].remove();

      const wrapper = document.createElement("div");
      wrapper.style.display = "flex";
      wrapper.style.gap = "4px";
      wrapper.style.flexWrap = "wrap";
      wrapper.style.pointerEvents = "auto";

      const tabs = Cast.toString(TABS).split(",").map(t => t.trim());
      this.tabGroups[id] = { active: tabs[0] || "", buttons: {} };

      for (const tab of tabs) {
        const btn = document.createElement("button");
        btn.textContent = tab;
        btn.style.padding = "8px 12px";
        btn.style.border = "1px solid rgba(255,255,255,0.25)";
        btn.style.borderRadius = "10px";
        btn.style.cursor = "pointer";
        btn.style.background = tab === this.tabGroups[id].active ? "linear-gradient(90deg,#8b5cf6,#4f46e5)" : "rgba(255,255,255,0.2)";
        btn.style.color = "#fff";

        btn.addEventListener("click", () => {
          this.tabGroups[id].active = tab;
          for (const key in this.tabGroups[id].buttons) {
            const b = this.tabGroups[id].buttons[key];
            const active = key === tab;
            b.style.background = active ? "linear-gradient(90deg,#8b5cf6,#4f46e5)" : "rgba(255,255,255,0.2)";
            b.style.color = "#fff";
          }
        });

        this.tabGroups[id].buttons[tab] = btn;
        wrapper.appendChild(btn);
      }

      parent.appendChild(wrapper);
      this.elements[id] = wrapper;
    }

    getActiveTab({ ID }) {
      const group = this.tabGroups[Cast.toString(ID)];
      return group ? group.active : "";
    }

    createSlider({ ID, PARENT, MIN, MAX, VALUE }) {
      const id = Cast.toString(ID);
      const parent = this._getParentContainer(PARENT);
      if (!parent) return;
      if (this.elements[id]) this.elements[id].remove();

      const input = document.createElement("input");
      input.type = "range";
      input.min = Cast.toNumber(MIN);
      input.max = Cast.toNumber(MAX);
      input.value = Cast.toNumber(VALUE);
      input.style.pointerEvents = "auto";
      input.style.width = "100%";

      parent.appendChild(input);
      this.elements[id] = input;
    }

    getSliderValue({ ID }) {
      const el = this.elements[Cast.toString(ID)];
      return el ? el.value : 0;
    }

    createColorPicker({ ID, PARENT, COLOR }) {
      const id = Cast.toString(ID);
      const parent = this._getParentContainer(PARENT);
      if (!parent) return;
      if (this.elements[id]) this.elements[id].remove();

      const input = document.createElement("input");
      input.type = "color";
      input.value = Cast.toString(COLOR);
      input.style.pointerEvents = "auto";

      parent.appendChild(input);
      this.elements[id] = input;
    }

    getColorPickerValue({ ID }) {
      const el = this.elements[Cast.toString(ID)];
      return el ? el.value : "#000000";
    }

    createImageElement({ ID, PARENT, URL, W, H }) {
      const id = Cast.toString(ID);
      const parent = this._getParentContainer(PARENT);
      if (!parent) return;
      if (this.elements[id]) this.elements[id].remove();

      const img = document.createElement("img");
      img.src = Cast.toString(URL);
      img.style.width = Cast.toNumber(W) + "px";
      img.style.height = Cast.toNumber(H) + "px";
      img.style.pointerEvents = "auto";

      parent.appendChild(img);
      this.elements[id] = img;
    }

    createIFrame({ ID, PARENT, URL, W, H }) {
      const id = Cast.toString(ID);
      const parent = this._getParentContainer(PARENT);
      if (!parent) return;
      if (this.elements[id]) this.elements[id].remove();

      const frame = document.createElement("iframe");
      frame.src = Cast.toString(URL);
      frame.width = Cast.toNumber(W);
      frame.height = Cast.toNumber(H);
      frame.style.border = "0";
      frame.style.borderRadius = "10px";
      frame.style.pointerEvents = "auto";

      parent.appendChild(frame);
      this.elements[id] = frame;
    }

    setElementHTML({ ID, HTML }) {
      const el = this.elements[Cast.toString(ID)];
      if (!el) return;
      if (el._body) el._body.innerHTML = Cast.toString(HTML);
      else el.innerHTML = Cast.toString(HTML);
    }

    setElementText({ ID, TEXT }) {
      const el = this.elements[Cast.toString(ID)];
      if (!el) return;
      if (el._body) el._body.textContent = Cast.toString(TEXT);
      else el.textContent = Cast.toString(TEXT);
    }

    setElementStyle({ ID, CSS }) {
      const el = this.elements[Cast.toString(ID)];
      if (el) el.style.cssText += ";" + Cast.toString(CSS);
    }

    removeElement({ ID }) {
      const id = Cast.toString(ID);
      if (this.elements[id]) {
        this.elements[id].remove();
        delete this.elements[id];
      }
      delete this.buttonClicks[id];
      delete this.tabGroups[id];
      delete this.attachedElements[id];
      delete this.overlayElements[id];
    }

    runJavaScript({ CODE }) {
      try {
        return String(eval(Cast.toString(CODE)));
      } catch (e) {
        return "Error: " + e.message;
      }
    }

    runMiniCode({ CODE }) {
      try {
        const code = Cast.toString(CODE).split("\n");
        const out = [];

        for (let line of code) {
          line = line.trim();
          if (!line) continue;

          if (line.startsWith("print ")) {
            out.push(line.slice(6));
          } else if (line.startsWith("set ")) {
            const rest = line.slice(4);
            const eq = rest.indexOf("=");
            if (eq !== -1) {
              const key = rest.slice(0, eq).trim();
              const value = rest.slice(eq + 1).trim();
              this.vars[key] = value;
            }
          } else if (line.startsWith("get ")) {
            const key = line.slice(4).trim();
            out.push(this.vars[key] || "");
          } else if (line.startsWith("alert ")) {
            alert(line.slice(6));
          } else if (line.startsWith("html ")) {
            const rest = line.slice(5);
            const sp = rest.indexOf(" ");
            if (sp !== -1) {
              const id = rest.slice(0, sp);
              const html = rest.slice(sp + 1);
              this.setElementHTML({ ID: id, HTML: html });
            }
          } else if (line.startsWith("style ")) {
            const rest = line.slice(6);
            const sp = rest.indexOf(" ");
            if (sp !== -1) {
              const id = rest.slice(0, sp);
              const css = rest.slice(sp + 1);
              this.setElementStyle({ ID: id, CSS: css });
            }
          }
        }

        return out.join("\n");
      } catch (e) {
        return "Error: " + e.message;
      }
    }

    async httpGet({ URL }) {
      try {
        const res = await fetch(Cast.toString(URL));
        const text = await res.text();
        this.lastHttpText = text;
        this.lastHttpStatus = res.status;
        return text;
      } catch (e) {
        this.lastHttpStatus = 0;
        return "Error: " + e.message;
      }
    }

    async httpPost({ URL, BODY }) {
      try {
        const res = await fetch(Cast.toString(URL), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: Cast.toString(BODY)
        });
        const text = await res.text();
        this.lastHttpText = text;
        this.lastHttpStatus = res.status;
        return text;
      } catch (e) {
        this.lastHttpStatus = 0;
        return "Error: " + e.message;
      }
    }

    httpLastStatus() {
      return this.lastHttpStatus;
    }

    fsCreateFile({ PATH, CONTENT }) {
      const info = this._getParentAndName(PATH);
      if (!info || !info.parent || info.parent.type !== "dir") return;
      info.parent.children[info.name] = { type: "file", content: Cast.toString(CONTENT) };
      this._saveFS();
    }

    fsReadFile({ PATH }) {
      const node = this._getNode(PATH);
      return node && node.type === "file" ? node.content : "";
    }

    fsWriteFile({ PATH, CONTENT }) {
      const node = this._getNode(PATH);
      if (node && node.type === "file") {
        node.content = Cast.toString(CONTENT);
        this._saveFS();
      }
    }

    fsMkdir({ PATH }) {
      const info = this._getParentAndName(PATH);
      if (!info || !info.parent || info.parent.type !== "dir") return;
      if (!info.parent.children[info.name]) {
        info.parent.children[info.name] = { type: "dir", children: {} };
        this._saveFS();
      }
    }

    fsList({ PATH }) {
      const node = this._getNode(PATH);
      if (!node || node.type !== "dir") return "[]";
      return JSON.stringify(Object.keys(node.children));
    }

    canvasCreate({ ID, W, H }) {
      const canvas = document.createElement("canvas");
      canvas.width = Cast.toNumber(W);
      canvas.height = Cast.toNumber(H);
      this.canvases[Cast.toString(ID)] = {
        canvas,
        ctx: canvas.getContext("2d")
      };
    }

    canvasRect({ ID, X, Y, W, H, COLOR }) {
      const c = this.canvases[Cast.toString(ID)];
      if (!c) return;
      c.ctx.fillStyle = Cast.toString(COLOR);
      c.ctx.fillRect(Cast.toNumber(X), Cast.toNumber(Y), Cast.toNumber(W), Cast.toNumber(H));
    }

    canvasCircle({ ID, X, Y, R, COLOR }) {
      const c = this.canvases[Cast.toString(ID)];
      if (!c) return;
      c.ctx.fillStyle = Cast.toString(COLOR);
      c.ctx.beginPath();
      c.ctx.arc(Cast.toNumber(X), Cast.toNumber(Y), Cast.toNumber(R), 0, Math.PI * 2);
      c.ctx.fill();
    }

    canvasText({ ID, TEXT, X, Y, SIZE, COLOR }) {
      const c = this.canvases[Cast.toString(ID)];
      if (!c) return;
      c.ctx.fillStyle = Cast.toString(COLOR);
      c.ctx.font = `${Cast.toNumber(SIZE)}px Arial`;
      c.ctx.fillText(Cast.toString(TEXT), Cast.toNumber(X), Cast.toNumber(Y));
    }

    canvasDataURL({ ID }) {
      const c = this.canvases[Cast.toString(ID)];
      return c ? c.canvas.toDataURL() : "";
    }

    vectorCreate({ NAME, X, Y, Z }) {
      this.vectors[Cast.toString(NAME)] = {
        x: Cast.toNumber(X),
        y: Cast.toNumber(Y),
        z: Cast.toNumber(Z)
      };
    }

    vectorAdd({ A, B }) {
      const a = this.vectors[Cast.toString(A)];
      const b = this.vectors[Cast.toString(B)];
      if (!a || !b) return "{}";
      return JSON.stringify({
        x: a.x + b.x,
        y: a.y + b.y,
        z: a.z + b.z
      });
    }

    particleCreate({ X, Y, VX, VY, LIFE }) {
      this.particles.push({
        x: Cast.toNumber(X),
        y: Cast.toNumber(Y),
        vx: Cast.toNumber(VX),
        vy: Cast.toNumber(VY),
        life: Cast.toNumber(LIFE)
      });
    }

    particleStep({ G }) {
      const g = Cast.toNumber(G);
      for (const p of this.particles) {
        p.vy += g;
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 1;
      }
      this.particles = this.particles.filter(p => p.life > 0);
    }

    particleCount() {
      return this.particles.length;
    }

    _findTargetByName(name) {
      const n = Cast.toString(name);
      return this.runtime.targets.find(t => !t.isStage && t.getName && t.getName() === n) || null;
    }

    spriteExists({ NAME }) {
      return !!this._findTargetByName(NAME);
    }

    spriteSetXY({ NAME, X, Y }) {
      const t = this._findTargetByName(NAME);
      if (!t) return;
      t.setXY(Cast.toNumber(X), Cast.toNumber(Y));
    }

    spriteSetCostumeByName({ NAME, COSTUME }) {
      const target = this._findTargetByName(NAME);
      if (!target) return;
      const costumeName = Cast.toString(COSTUME);
      const idx = target.sprite.costumes.findIndex(c => c.name === costumeName);
      if (idx >= 0) target.setCostume(idx);
    }

    _stageToScreen(x, y) {
      const canvas = document.querySelector("canvas");
      if (!canvas) return { x: 0, y: 0 };
      const rect = canvas.getBoundingClientRect();
      const sx = rect.width / 480;
      const sy = rect.height / 360;
      return {
        x: rect.left + rect.width / 2 + x * sx,
        y: rect.top + rect.height / 2 - y * sy
      };
    }

    _startOverlayLoop() {
      const update = () => {
        for (const id in this.attachedElements) {
          const item = this.attachedElements[id];
          const el = this.overlayElements[id];
          const target = this._findTargetByName(item.sprite);
          if (!el || !target) continue;
          const pos = this._stageToScreen(target.x + item.dx, target.y + item.dy);
          el.style.left = pos.x + "px";
          el.style.top = pos.y + "px";
          el.style.transform = "translate(-50%, -50%)";
        }
        requestAnimationFrame(update);
      };
      requestAnimationFrame(update);
    }

    attachLabelToSprite({ ID, SPRITE, TEXT, DX, DY }) {
      const root = this._getRoot();
      const id = Cast.toString(ID);

      if (this.overlayElements[id]) this.overlayElements[id].remove();

      const el = document.createElement("div");
      el.textContent = Cast.toString(TEXT);
      el.style.position = "fixed";
      el.style.pointerEvents = "none";
      el.style.color = "#fff";
      el.style.fontFamily = "Arial, sans-serif";
      el.style.fontWeight = "bold";
      el.style.textShadow = "0 1px 3px rgba(0,0,0,0.8)";
      el.style.zIndex = "1000001";

      root.appendChild(el);
      this.overlayElements[id] = el;
      this.attachedElements[id] = {
        sprite: Cast.toString(SPRITE),
        dx: Cast.toNumber(DX),
        dy: Cast.toNumber(DY)
      };
    }

    docsSections() {
      return [
        "окна",
        "ui",
        "html",
        "css",
        "javascript",
        "mini-code",
        "файлы",
        "запросы",
        "canvas",
        "векторы",
        "частицы",
        "спрайты"
      ].join(", ");
    }

    docsGet({ SECTION }) {
      const s = Cast.toString(SECTION).toLowerCase();
      const docs = {
        "окна": "createWindow создаёт красивое draggable окно. Есть showWindow, hideWindow, moveWindow, resizeWindow, centerWindow.",
        "ui": "Есть label, button, input, textarea, checkbox, progress, list, tabs, slider, color picker, image, iframe.",
        "html": "setElementHTML вставляет HTML в элемент или тело окна.",
        "css": "setElementStyle применяет CSS строкой к элементу.",
        "javascript": "runJavaScript выполняет JS и возвращает результат.",
        "mini-code": "Поддерживаются команды: print, set, get, alert, html, style.",
        "файлы": "Есть виртуальная ФС: создание, чтение, запись, папки, список.",
        "запросы": "Есть httpGet, httpPost, httpLastStatus.",
        "canvas": "Есть canvasCreate, canvasRect, canvasCircle, canvasText, canvasDataURL.",
        "векторы": "Есть создание и сложение векторов.",
        "частицы": "Есть particleCreate, particleStep, particleCount.",
        "спрайты": "Есть spriteExists, spriteSetXY, spriteSetCostumeByName, attachLabelToSprite."
      };
      return docs[s] || "Раздел не найден.";
    }
  }

  Scratch.extensions.register(new MegaStudioExtensionV2MAX());
})(Scratch);